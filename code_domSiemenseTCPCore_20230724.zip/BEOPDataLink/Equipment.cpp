#include "StdAfx.h"
#include "Equipment.h"



Equipment::Equipment()
{
	m_wstrEnableType = L"const";
	m_wstrEnableBindName = L"1";
	m_wstrEquipmentName = L"";
}


Equipment::~Equipment(void)
{

}