#pragma once
class CCoreUnitTest
{
public:
	CCoreUnitTest(void);
	~CCoreUnitTest(void);

	bool RunTest();
	bool Test01();
	bool Test02();

	bool Test03();

	bool RunCommon();

};

